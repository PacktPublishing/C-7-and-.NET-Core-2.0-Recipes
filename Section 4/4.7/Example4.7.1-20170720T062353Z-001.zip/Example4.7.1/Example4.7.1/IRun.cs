﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Example4._7._1
{
    public interface IRun
    {
        void Run(int distance);
    }
}

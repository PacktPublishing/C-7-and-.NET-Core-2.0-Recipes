﻿using System;

namespace Example4._1._2
{
    class Program
    {
        static void Main(string[] args)
        {
            var car = getCar();
            Console.WriteLine($"Model: {car.Model}");
            Console.WriteLine($"Price: {car.Price}");
            Console.WriteLine($"Currency: {car.Currency}");
            Console.ReadKey();
        }

        private static (string Model, double Price, string Currency) getCar()
        {
            return ("Tesla Model S", 75000, "USD");
        }
    }
}

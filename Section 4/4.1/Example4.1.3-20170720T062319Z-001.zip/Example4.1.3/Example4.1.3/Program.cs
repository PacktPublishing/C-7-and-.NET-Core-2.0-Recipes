﻿using System;

namespace Example4._1._3
{
    class Program
    {
        static void Main(string[] args)
        {
            (string model, double price, string currency) = getCar();
            Console.WriteLine($"Model: {model}");
            Console.WriteLine($"Price: {price}");
            Console.WriteLine($"Currency: {currency}");
            Console.ReadKey();
        }

        private static (string Model, double Price, string Currency) getCar()
        {
            return ("Tesla Model S", 75000, "USD");
        }
    }
}

﻿using System;

namespace Example4._3._1
{
    class Program
    {
        static void Main(string[] args)
        {
            Person p = new Person("John", "Smith", 23);
            int age = p.GetAge();
            ref int ageRef = ref p.GetAge();
            ageRef++;
            Console.WriteLine(p);
            Console.ReadKey();
        }
    }
}

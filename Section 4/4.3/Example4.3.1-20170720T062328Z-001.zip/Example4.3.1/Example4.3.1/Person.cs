﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Example4._3._1
{
    public class Person
    {
        public string FirstName { get; private set; }
        public string LastName { get; private set; }
        private int _age;

        public Person(string firstName, string lastName, int age)
        {
            FirstName = firstName;
            LastName = lastName;
            _age = age;
        }

        public ref int GetAge()
        {
            return ref _age;
        }

        public override string ToString()
        {
            return $"{FirstName} {LastName} / {_age}";
        }
    }
}

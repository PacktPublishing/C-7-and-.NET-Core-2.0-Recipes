﻿using System;

namespace Example4._3._2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadKey();
        }

        /// <summary>
        /// Warning: This method is not supposed to work
        /// It is a demo of ref local bad usage
        /// </summary>
        private static ref double getDoubleRef()
        {
            double value = 3.14;
            return ref value;
        }
    }
}

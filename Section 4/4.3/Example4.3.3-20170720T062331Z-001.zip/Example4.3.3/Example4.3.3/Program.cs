﻿using System;

namespace Example4._3._3
{
    class Program
    {
        /// <summary>
        /// Warning: This method is not supposed to work
        /// It's a demonstration of bad usage of ref locals & returns
        /// </summary>
        static void Main(string[] args)
        {
            ref int result = ref sum(1, 2);
            Console.ReadKey();
        }

        private static int sum(int a, int b)
        {
            return a + b;
        }
    }
}

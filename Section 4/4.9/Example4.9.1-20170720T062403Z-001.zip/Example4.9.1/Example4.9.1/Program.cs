﻿using System;

namespace Example4._9._1
{
    class Program
    {
        static void Main(string[] args)
        {
            double number = 1_750_036.49;
            Console.WriteLine(number);
            Console.ReadKey();
        }
    }
}
﻿using System;

namespace Example4._9._2
{
    class Program
    {
        static void Main(string[] args)
        {
            int myBinary = 0b1000_0010;
            Console.WriteLine(myBinary);
            Console.ReadKey();
        }
    }
}
﻿using System;

namespace Example4._4._1
{
    class Program
    {
        static void Main(string[] args)
        {
            calculate(8, 2, out var sum, out var diff);
            Console.WriteLine($"Sum: {sum}");
            Console.WriteLine($"Diff: {diff}");
            Console.ReadKey();
        }

        private static void calculate(int a, int b, out int sum, out int diff)
        {
            sum = a + b;
            diff = a - b;
        }
    }
}

﻿using System;
using System.Threading.Tasks;
using System.IO;

namespace Example4._8._1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadKey();
        }

        private static async Task<bool> getBoolOldWayAsync()
        {
            await Task.Delay(3000);
            return false;
        }

        private static async ValueTask<bool> getBoolAsync()
        {
            await Task.Delay(3000);
            return true;
        }
    }
}

﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace Example7._2._3
{
    class Program
    {
        static void Main(string[] args)
        {
            writeFiles();
            Console.ReadKey();
        }

        private static void writeFiles()
        {
            int tasksAmount = 10;
            Task[] tasks = new Task[tasksAmount];

            Console.WriteLine("Writing tasks started");
            for(int i=0; i<tasksAmount; i++)
            {
                string fileName = $"log-{i + 1}.txt";
                int id = i + 1;
                tasks[i] = Task.Run(() =>
                {
                    Console.WriteLine($"Task {id} running on thread: {Thread.CurrentThread.ManagedThreadId} / writing file {fileName}");
                    var generator = new ReportGenerator(fileName);
                    generator.Generate();
                });
            }
            Task.WaitAll(tasks);
            Console.WriteLine("Writing tasks finished");
        }
    }
}

﻿using System;
using System.Threading;

namespace Example7._2._2
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLogs();
            Console.ReadKey();
        }

        private static void WriteLogs()
        {
            int logFilesAmount = 10;
            
            for (int i = 0; i < logFilesAmount; i++)
            {
                var logManager = new LogManager($"log-{i + 1}.txt");
                ThreadPool.QueueUserWorkItem(new WaitCallback((o) => { logManager.Generate(); }));
            }
            Console.WriteLine("Files written");
        }
    }
}

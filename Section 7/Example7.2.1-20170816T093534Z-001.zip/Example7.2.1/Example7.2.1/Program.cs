﻿using System;
using System.Threading;

namespace Example7._2._1
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLogs();
            Console.ReadKey();
        }

        private static void WriteLogs()
        {
            int logFilesAmount = 10;
            Thread[] threads = new Thread[logFilesAmount];
            Console.WriteLine("Starting writer threads...");
            for (int i=0; i<logFilesAmount; i++)
            {
                var logManager = new LogManager($"log-{i + 1}.txt");
                threads[i] = new Thread(logManager.Generate);
                threads[i].Start();
            }

            for(int i=0; i<logFilesAmount; i++)
            {
                threads[i].Join();
            }
            Console.WriteLine("All writer threads finished");
        }
    }
}

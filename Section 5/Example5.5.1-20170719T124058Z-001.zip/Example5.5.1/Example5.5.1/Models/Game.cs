﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Example5._5._1.Models
{
    public class Game
    {
        public string Title { get; set; }
        public string Genre { get; set; }
    }
}

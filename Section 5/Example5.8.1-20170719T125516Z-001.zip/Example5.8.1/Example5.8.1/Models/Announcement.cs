﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Example5._8._1.Models
{
    public class Announcement
    {
        public string Title { get; set; }
        public string Content { get; set; }
    }
}

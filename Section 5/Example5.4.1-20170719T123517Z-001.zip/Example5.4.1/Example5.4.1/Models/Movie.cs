﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Example5._4._1.Models
{
    public class Movie
    {
        public string Title { get; set; }
        public int Ranking { get; set; }
    }
}
